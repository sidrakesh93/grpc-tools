# Protocol Buffers
This package contains the definitions of Well-Known Types of Protocol
Buffers Language version 3 (proto3). These types have stable and
well-defined semantics. They are natively supported by proto3 compiler
and runtime. Application developers should use these types in their
applications instead of inventing their own types for the same purpose.
